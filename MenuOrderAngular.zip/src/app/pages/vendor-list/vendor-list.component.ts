import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vender-list',
  templateUrl: './vendor-list.component.html',
  styleUrls: ['./vendor-list.component.scss']
})
export class VendorListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
