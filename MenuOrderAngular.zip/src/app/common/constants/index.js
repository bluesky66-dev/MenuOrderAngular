export const AUTH_REGISTER = "auth:register";
