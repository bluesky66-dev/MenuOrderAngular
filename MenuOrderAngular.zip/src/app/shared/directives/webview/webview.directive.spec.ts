import { WebviewDirective } from './webview.directive';

describe('WebviewDirective', () => {
  it('should create an instance', () => {
    const directive = new WebviewDirective();
    expect(directive).toBeTruthy();
  });
});
