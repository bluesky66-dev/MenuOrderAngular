export const AppConfig = {
  production: true,
  environment: 'PROD',
  DB_HOST: 'mongodb+srv',
  DB_NAME: 'lunchapp',
  DB_SECRET: '3851f34d13937b673a7d24a1950bb5b21!',
  DB_USER: 'king-mancer',
  DB_PASS: 'SRqqv4o1iim4TyZK',
  SESSION_SECRET: '168o1kqNquEJeR9vosUB5fw4eAwcVAgh8!',
  MAILER_USER: 'autonomymatrix@gmail.com',
  MAILER_PASS: 'R117PaLgjJhu2WJ7CrjpaXpvHsusyL81efetz',
};
