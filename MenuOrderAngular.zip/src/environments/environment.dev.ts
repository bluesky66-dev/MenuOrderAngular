// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `index.ts`, but if you do
// `ng build --env=prod` then `index.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const AppConfig = {
  production: false,
  environment: 'DEV',
  DB_HOST: 'mongodb',
  DB_NAME: 'lunchapp',
  DB_SECRET: '',
  DB_USER: '',
  DB_PASS: '',
  SESSION_SECRET: '168o1kqNquEJeR9vosUB5fw4eAwcVAgh8!',
  MAILER_USER: 'autonomymatrix@gmail.com',
  MAILER_PASS: 'R117PaLgjJhu2WJ7CrjpaXpvHsusyL81efetz',
};
